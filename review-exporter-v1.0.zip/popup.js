// ReviewExporter v1.0

const REVIEWMINER_URL = 'https://reviewminer.xyz';
var reviews = [];
var productName = '';
var productUrl = '';

var scanBtn = document.getElementById('scanBtn');
var exportCsvBtn = document.getElementById('exportCsvBtn');
var analyzeBtn = document.getElementById('analyzeBtn');
var statusEl = document.getElementById('status');
var countBadge = document.getElementById('count');
var preview = document.getElementById('preview');
var productInfo = document.getElementById('productInfo');
var productNameEl = document.getElementById('productName');
var reviewCountEl = document.getElementById('reviewCount');
var exportStatus = document.getElementById('exportStatus');
var reviewminerLink2 = document.getElementById('reviewminerLink2');

reviewminerLink2.href = REVIEWMINER_URL;

async function scanPage() {
  preview.innerHTML = '<div class="preview-empty">Scanning page for reviews...</div>';
  reviews = [];
  try {
    var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    var tab = tabs[0];
    if (!tab) { showStatus('No active tab found', 'error'); return; }

    var response = await chrome.tabs.sendMessage(tab.id, { action: 'getReviews' });
    if (!response || !response.reviews) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      var retry = await chrome.tabs.sendMessage(tab.id, { action: 'getReviews' });
      if (retry && retry.reviews) {
        reviews = retry.reviews;
        productName = retry.productName || 'Unknown Product';
        productUrl = retry.url || tab.url;
      }
    } else {
      reviews = response.reviews;
      productName = response.productName || 'Unknown Product';
      productUrl = response.url || tab.url;
    }

    if (reviews.length === 0) {
      preview.innerHTML = '<div class="preview-empty">No reviews found. Try an Amazon product page.</div>';
      countBadge.textContent = '0 reviews found';
      exportCsvBtn.disabled = true; analyzeBtn.disabled = true;
      productInfo.classList.add('hidden'); return;
    }

    countBadge.textContent = reviews.length + ' reviews found';
    exportCsvBtn.disabled = false; analyzeBtn.disabled = false;
    productNameEl.textContent = productName;
    reviewCountEl.textContent = reviews.length + ' reviews';
    productInfo.classList.remove('hidden');
    renderPreview();
    showStatus('Found ' + reviews.length + ' reviews', 'success');
  } catch (err) {
    console.error('ReviewExporter error:', err);
    showStatus('Could not access this page. Try refreshing.', 'error');
  }
}

function renderPreview() {
  var show = reviews.slice(0, 8);
  preview.innerHTML = show.map(function(r, i) {
    var stars = r.rating ? parseInt(r.rating) : 0;
    var starStr = '';
    for (var s = 0; s < 5; s++) starStr += s < stars ? '[star]' : '[empty]';
    return '<div class="review-item">' +
      (r.rating ? '<div class="review-rating">' + starStr + ' ' + r.rating + '</div>' : '') +
      (r.title ? '<div class="review-title">' + escapeHtml(r.title) + '</div>' : '') +
      '<div class="review-body">' + escapeHtml(r.body.slice(0, 200)) + '</div>' +
      '<div class="review-meta">' + [r.author, r.date, r.verified].filter(Boolean).join(' ') + '</div></div>';
  }).join('');
  if (reviews.length > 8) {
    preview.innerHTML += '<div class="preview-empty">+ ' + (reviews.length - 8) + ' more in export...</div>';
  }
}

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function exportCsv() {
  if (reviews.length === 0) return;
  var headers = ['title', 'body', 'rating', 'author', 'date', 'verified'];
  var csv = headers.join(',') + '\n';
  reviews.forEach(function(r) {
    csv += headers.map(function(h) {
      return '"' + String(r[h] || '').replace(/"/g, '""').replace(/\n/g, ' ') + '"';
    }).join(',') + '\n';
  });
  var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  var url = URL.createObjectURL(blob);
  chrome.downloads.download({ url: url, filename: 'reviews.csv', saveAs: false });
  showStatus('Exported ' + reviews.length + ' reviews as CSV', 'success');
  exportStatus.textContent = 'Last export: ' + reviews.length + ' reviews';
  setTimeout(function() { statusEl.classList.add('hidden'); }, 2000);
}

function openReviewMiner() {
  chrome.tabs.create({ url: REVIEWMINER_URL + '/dashboard' });
  chrome.storage.local.set({ exportedAt: Date.now(), count: reviews.length });
  showStatus('Opening ReviewMiner... Paste reviews for AI analysis!', 'info');
}

function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className = 'status ' + type;
  statusEl.classList.remove('hidden');
}

scanBtn.addEventListener('click', scanPage);
exportCsvBtn.addEventListener('click', exportCsv);
analyzeBtn.addEventListener('click', openReviewMiner);
scanPage();
